This is done as an assignment of course CS631 in IIT Bombay.
We have implemented extended hashing and compared it with existing AM Layer.

To run the program we need to follow the commands:

1. For performing various operations on extended hashing
   a.goto folder name 'Extended Hashing with interface' 
   b.goto folder name 'pflayer' 
   c.run command 'make'
   d.run command 'make testhash'
   e.run command './testhash'

2.For performing comparision operation between AM layer and extended hashing
  a.goto folder name 'Comparision of extended hashing with am layer'
  b.goto folder name 'pflayer'
  c.run command 'make'
  d.goto folder name 'amlayer'
  e.run command 'make'
  f.run command './a.out'

Collaborators:-
Avais Ahmad
Pratik Wagh
